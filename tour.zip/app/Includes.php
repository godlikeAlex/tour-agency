<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Includes extends Model
{
    protected $guarded = [];
}
