<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TourDatesAbout extends Model
{
    protected $guarded = [];
}
