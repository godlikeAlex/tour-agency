<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Uzbekistan extends Model
{
    protected $guarded = [] ;
}
