<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Создание объекта для города</div>

                <div class="card-body">
                    <form action="" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <input type="text" name="name" class="form-control" placeholder="Название объекта">
                        </div>
                        <div class="form-group">
                                <label for="exampleSelect1">Город в котором находиться объект.</label>
                                <select name="city_id" class="form-control" id="exampleSelect1">
                                    <?php $__currentLoopData = $citys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                        </div>
                        <div class="form-group">
                                <label for="exampleSelect1">Язык контент.</label>
                                <select name="lang" class="form-control" id="exampleSelect1">
                                        <option value="ru">Русский язык</option>
                                        <option value="en">Английский язык</option>
                                </select>
                        </div>
                        <div class="form-group">
                                <label for="exampleSelect1">Ценновая категория использовать только для Ресторанов и Отелей в остальных случаях оставлять пустым полем.</label>
                                <select name="category_price" class="form-control" id="exampleSelect1">
                                        <option value="">Без ценовой категории</option>
                                        <option value="cheap">Дешевый</option>
                                        <option value="middle">Средний</option>
                                        <option value="expensive">Дорогой</option>
                                </select>
                        </div>
                        <div class="form-group">
                                <label for="exampleSelect1">Тип объекта.</label>
                                <select name="category" class="form-control" id="exampleSelect1">
                                    <option value="history">История</option>
                                    <option value="what-to-see">Что посмотреть</option>
                                    <option value="things-to-do">Чем заняться</option>
                                    <option value="where-to-buy">Где покупать</option>
                                    <option value="where-to-eat">Где поесть</option>
                                    <option value="where-to-stay">Где остановиться</option>
                                    <option value="how-to-get">Как добраться</option>
                                    <option value="useful-information">Полезная информация</option>
                                </select>
                        </div>
                        <div class="form-group">
                            <p>Изображение объекта(Ресторана, парка тд тп).</p>
                            <input type="file" name="image">
                        </div>
                        <div class="form-group" style="padding-top:10px; padding-bottom:10px;">
                            <textarea name="preview" class="form-control" rows="5" placeholder="Краткое описание объекта для превью"></textarea>
                        </div>
                        <textarea name="about" id="summernote"></textarea>
                        <button type="submit" class="btn btn-success">Создать</button>
                    </form>                    
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>

<script>
      $('#summernote').summernote({
        placeholder: 'Полное описание объекта',
        tabsize: 2,
        height: 400
      });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Александр\Desktop\Projects\Laravel\tour\resources\views/admin/city-items-create.blade.php ENDPATH**/ ?>