<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!--===============================================================================================-->
           <link rel="stylesheet" type="text/css" href="/vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="/fonts/fontawesome-5.0.8/css/fontawesome-all.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="/fonts/iconic/css/material-design-iconic-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="/css/main.css">
    <link rel="stylesheet" href="/css/tour-all.css">
    <!--===============================================================================================-->
    <script src="https://kit.fontawesome.com/cdcf5aa2f7.js"></script>
    <link rel="stylesheet" type="text/css" href="/css/card.css"> 
    <link rel="stylesheet" type="text/css" href="/css/main-menu.css">
    <link rel="stylesheet" type="text/css" href="/css/main-page.css">
    <title>Document</title>
</head>
<body>
    <?php echo $__env->make('/components/header', ['type' => 'city'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="col-md-10" style="padding:0;">
            <div class="row">
                <?php if($items[0]->category_price): ?>
                    <div class="col-md-12 sub-category" style="font-size:25px; margin-top:50px; margin-bottom:20px;">Дешевый</div>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->category_price === 'cheap'): ?>
                        <article class="col-md-4 block_main__item">
                            <div class="content-block__img"><img src="/storage/<?php echo e($item->image); ?>" alt=""></div>
                            <div class="content-block__category">
                                <?php if($item->category_price === 'cheap'): ?>
                                    Дешевый
                                <?php elseif($item->category_price === 'middle'): ?>
                                    Средний
                                <?php elseif($item->category_price === 'expensive'): ?>
                                    Элитный
                                <?php endif; ?>
                            </div>
                            <div class="content-block__title"><a  href="<?php echo e(Request::url()); ?>/<?php echo e($item->slug); ?>"><?php echo e($item->name); ?></a></div>
                        </article>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12 sub-category" style="font-size:25px; margin-top:50px; margin-bottom:20px;">Средний</div>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->category_price === 'middle'): ?>
                        <article class="col-md-4 block_main__item">
                            <div class="content-block__img"><img src="/storage/<?php echo e($item->image); ?>" alt=""></div>
                            <div class="content-block__category">
                                <?php if($item->category_price === 'cheap'): ?>
                                    Дешевый
                                <?php elseif($item->category_price === 'middle'): ?>
                                    Средний
                                <?php elseif($item->category_price === 'expensive'): ?>
                                    Элитный
                                <?php endif; ?>
                            </div>
                            <div class="content-block__title"><a  href="<?php echo e(Request::url()); ?>/<?php echo e($item->slug); ?>"><?php echo e($item->name); ?></a></div>
                        </article>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12 sub-category" style="font-size:25px; margin-top:50px; margin-bottom:20px;">Дорогой</div>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->category_price === 'expensive'): ?>
                        <article class="col-md-4 block_main__item">
                            <div class="content-block__img"><img src="/storage/<?php echo e($item->image); ?>" alt=""></div>
                            <div class="content-block__category">
                                <?php if($item->category_price === 'cheap'): ?>
                                    Дешевый
                                <?php elseif($item->category_price === 'middle'): ?>
                                    Средний
                                <?php elseif($item->category_price === 'expensive'): ?>
                                    Элитный
                                <?php endif; ?>
                            </div>
                            <div class="content-block__title"><a  href="<?php echo e(Request::url()); ?>/<?php echo e($item->slug); ?>"><?php echo e($item->name); ?></a></div>
                        </article>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="col-md-4 block_main__item">
                            <div class="content-block__img"><img src="/storage/<?php echo e($item->image); ?>" alt=""></div>
                            <div class="content-block__title"><a  href="<?php echo e(Request::url()); ?>/<?php echo e($item->slug); ?>"><?php echo e($item->name); ?></a></div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    
        <?php echo e($items->links()); ?>

    </div>



    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="/js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="/js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <!-- Plugins js -->
    <script src="/js/plugins.js"></script>
    <!-- Active js -->
    <script src="/js/active.js"></script>
    <script src="/vendor/bootstrap/js/popper.js"></script>
    <script src="/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="/js/main.js"></script>
    <script type="text/javascript" src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
    <script>
        $('.responsive').slick({
            infinite: true,
            speed: 300,
            slidesToShow: 4,
            slidesToScroll: 4,
            prevArrow: '<button class="slide-arrow prev-arrow"><i class="fas fa-chevron-left"></i></button>',
            nextArrow: '<button class="slide-arrow next-arrow"><i class="fas fa-chevron-right"></i></button>',
            responsive: [
                {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true,
                    dots: true
                }
                },
                {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
                },
                {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
                }
            ]
            });
            $('.selector').slick({
                nextArrow: '<i class="fa fa-arrow-right"></i>',
                prevArrow: '<i class="fa fa-arrow-left"></i>',
                // add the rest of your options here
            });
    </script>
</body>
</html><?php /**PATH C:\Users\Александр\Desktop\Projects\Laravel\tour\resources\views/city-category.blade.php ENDPATH**/ ?>