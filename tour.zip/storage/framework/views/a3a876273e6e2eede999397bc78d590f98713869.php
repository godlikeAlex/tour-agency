<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="row justify-content-center">
        <div class="col-md-8">
            <div style="display: flex;
    justify-content: space-between;">
                <a href="/admin/tour/dates/all">
                    Все туры
                </a>
                
                <a href="/admin/tour/dates/create">
                    Добавить дату для тура
                </a>
                <a href="/admin/tour/create">
                    Создать тур
                </a>
            </div>
            <div class="card" style="margin-top:25px">
                <div class="card-header"> для тура</div>
                <div class="card-body">
                    <form action="<?php echo e(route('date.create')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>  
                        <div class="form-group">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Название тура</th>
                                    <th scope="col">Изменить</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <th scope="row"><?php echo e($tour->id); ?></th>
                                    <td><?php echo e($tour->name); ?></td>
                                    <td><a href="/admin/tour/dates/edit/<?php echo e($tour->id); ?>" class="btn btn-primary">Изменить <?php echo e($tour->id); ?></a></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                </table>
                        </div>
                    </form>                    
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>
<script>
    const addDate = document.querySelector('#addDate');
    addDate.addEventListener('click', () => {
        const template = ' <div class="form-group"> Начинается <input type="text" class="form-control" name="starts[]" placeholder="starts date"> </div> <div class="form-group"> Кончается <input type="text" class="form-control" name="ends[]" placeholder="ends date"> </div> <div class="form-group"> <label for="exampleSelect1">Статус</label> <select name="status[]" class="form-control" id="exampleSelect1"> <option value="avaliable">available</option> <option value="closed">сlosed</option> </select> </div> <div class="form-group"> <input class="form-control" type="text" name="lang[]" placeholder="Язык"> </div>';
        document.querySelector('#containerDate').innerHTML += template;
    })
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Александр\Desktop\Projects\Laravel\tour\resources\views/admin/all-dates.blade.php ENDPATH**/ ?>